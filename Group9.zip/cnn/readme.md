## Subreddits:

| ID  | Topic         | Subreddit                            |
| --- | ------------- | ------------------------------------ |
| 1   | politics      | politics, POLITIC                    |
| 2   | news          | news, worldnews, betternews          |
| 3   | technology    | technology, techsupport, programming |
| 4   | science       | askscience, science                  |
| 5   | food          | CookingRecipesStuff, food            |
| 6   | sports        | soccer, sports, nba                  |
| 7   | pokemon       | pokemon                              |
| 8   | relationships | relationships                        |
| 9   | de            | de                                   |
